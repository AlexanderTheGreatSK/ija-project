# IJA PROJECT 2021/2022
****
Simple JavaFX application

Authors:

Used Technology:

Points: