package com.example.ijaproject;

import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;

public class ArrowController {
    @FXML
    public Line lineA;

    @FXML
    public Line lineB;

    @FXML
    private Pane paneMove;

}
