package com.example.ijaproject;

public class ActorHolder {
    public String name;
}
