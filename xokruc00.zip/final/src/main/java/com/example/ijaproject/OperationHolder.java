package com.example.ijaproject;

public class OperationHolder {
    public String sourceName;
    public String targetName;
    public String operation;

    public OperationHolder(String sourceName, String targetName, String operation) {
        this.sourceName = sourceName;
        this.targetName = targetName;
        this.operation = operation;
    }
}
